<?php
require('handlers/isSessionValid.php');
?>
<section>
<link rel="stylesheet" href="css/shoppingcart.css">

<?php
require('printers/showOrders.php');
?>
</section>