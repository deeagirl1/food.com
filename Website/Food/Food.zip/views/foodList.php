<?php
require('handlers/isSessionValid.php');
?>
<link rel="stylesheet" href="css/restaurantList.css">

<section>

<?php
require('printers/showFood.php');
?>
</section>
<script src="js/addToCart.js"></script>