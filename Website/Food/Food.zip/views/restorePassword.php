<section>
<link rel="stylesheet" href="css/login.css">
<div class="container">
<form action="login.php">
    <p>You will recieve an email with instructions.</p><hr>
    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Email" name="email" id="email" required>

    <button type="submit">Send</button>
</form>
</div>
</section>